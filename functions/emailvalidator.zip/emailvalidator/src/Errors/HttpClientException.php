<?php

namespace NeverBounce\Errors;

class HttpClientException extends GeneralException
{
}
