<?php

namespace NeverBounce\Errors;

class ThrottleException extends GeneralException
{
}
