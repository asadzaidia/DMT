<?php

namespace NeverBounce\Errors;

class BadReferrerException extends GeneralException
{
}
