<?php

namespace NeverBounce\Errors;

class GeneralException extends \Exception
{
}
