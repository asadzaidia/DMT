<?php

namespace NeverBounce\Errors;

class AuthException extends GeneralException
{
}
