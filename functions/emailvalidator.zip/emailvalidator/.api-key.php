<?php

$api_key = "private_a8f68bee7748542782deae787ed64fe7";


?>